import FromUn

print(FromUn.monty_hall(1000))

print(FromUn.findChanse(23, 1000))